﻿namespace TradeStationAPIAuth2
{
    internal class AccountInfo
    {
        public string Alias { get; set; }
        public string AltId { get; set; }
        public string DisplayName { get; set; }
        public int Key { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public string TypeDescription { get; set; }
    }
}